from colorama import Fore

r = Fore.RED
g = Fore.GREEN
y = Fore.YELLOW
w = Fore.WHITE

# Мне просто удобно так, зачем сразу злиться?